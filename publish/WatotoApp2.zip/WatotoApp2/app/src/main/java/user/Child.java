package user;

/**
 * Created by victor on 10/9/2017.
 * This class does monitor all the child's
 * related information
 */

public class Child {

    public static final String SEX_MALE = "MALE";
    public static final String SEX_FEMALE = "FEMALE";

    private String birth_date;
    private String sex;
    private User parent;

    public Child () {
        this.birth_date = null;
        this.sex = null;
        this.parent = null;
    }

    public Child (String birth_date, String sex, User parent){
        this.birth_date = birth_date;
        this.sex = sex;
        this.parent = parent;
    }

    public String getBirth_date(){
        return this.birth_date;
    }

    public String getSex(){
        return this.sex;
    }

    public User getParent(){
        return this.parent;
    }

    public void setBirth_date(String birth_date){
        this.birth_date = birth_date;
    }

    public void setSex(String sex){
        this.sex = sex;
    }

    public void setParent(User parent){
        this.parent = parent;
    }

    public void setSexMale(){
        this.sex = SEX_MALE;
    }

    public void setSexFemale(){
        this.sex = SEX_FEMALE;
    }
}
